// a utility class for resuable functions

// import bcrypt
const bcrypt = require("bcrypt");
const salt = 10;

// example
exports.utils = {
  // validation functions
  validateUsername(username) {
    // Check if the username is at least 3 characters long
    if (username.length < 3) return false;
    return true;
  },
  validateEmail(email, prisma) {
    // Regular expression for a simple email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailRegex.test(email)) return false;
    return true;
  },
  validatePassword(password) {
    // Regular expression for password validation
    const passwordRegex =
      /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

    if (!passwordRegex.test(password)) return false;
    return true;
  },
  // encryption
  encrypt(password) {
    return bcrypt.hashSync(password, salt);
  },
  decrypt(password, match) {
    // check if the passwords match
    // return true or false
  },
  // tbd
};
