const User = require("../models/user.model.js");
const util = require("./controller.util.js");

// const { body, validationResult } = require("express-validator");

const { PrismaClient } = require("@prisma/client");

const prisma = new PrismaClient();

exports.createOne = async (req, res) => {
  const user = req.body.user;
  console.log(user);

  let validUsername = false;
  let validEmail = false;
  let validPassword = false;

  // re-validate user information
  validUsername = util.utils.validateUsername(user.username);
  let usernameTest = await User.findBy("username", user.username);
  if (usernameTest) {
    validUsername = false; // username is already in the DB
    res.err = "That username is already taken.";
    res.status(500).send();
    return;
  }

  validEmail = util.utils.validateEmail(user.email);
  let emailTest = await User.findBy("email", user.email);
  if (emailTest) {
    validEmail = false; // email is already in the DB
    res.text = "That email is already connected to an account.";
    res.status(500).send({err: "That email is already connected to an account."});
  }
  validPassword = util.utils.validatePassword(user.password);

  // if all are validated, then we are good to go.
  userIsValid = validUsername && validEmail && validPassword;

  // if user is valid,
  if (userIsValid) {
    //    encrypt password
    const ePassword = util.utils.encrypt(user.password);
    if (!ePassword) {
      console.error("There was some error hashing the password.");
    } else {
      //    add to the database
      const data = {
        username: user.username,
        email: user.email,
        password: ePassword,
        posts: [],
        Rating: [],
        createdDate: new Date(),
      };
      let createResult = await User.create({
        data,
      });
      if (!createResult) {
        res.status(500).send({
          message: "Some error occurred while creating the user",
        });
      } else {
        res.status(200).send({
          message: "User created successfully",
        });
      }
    }
  }

  console.log("userIsValid: ", userIsValid);
};

exports.findAll = async (req, res) => {
  const users = await User.getAll();
  if (!users) {
    res.status(500).send({
      message: "Some error occurred while retrieving users.",
    });
  } else res.status(200).send(users);
};
