<script setup>
import CYAForm from './CYAForm.vue'
</script>

<template>
  <button type="button" @click="showCYAForm">Create Your Account</button>
  <div v-if="showForm">
    <CYAForm />
  </div>
</template>

<script>
export default {
  data() {
    return {
      showForm: false,

    }
  },
  methods: {
    showCYAForm() {
      console.log('showCYAForm()')
      this.showForm = true
    },
    cancelCYAForm() {
      // clear all inputs fields
      this.showForm = false
    },
    submitCYAForm() {
      console.log('Create account function')

      // get all input values 
      // validate all input values 
      // create a new user in the database
      // redirct to login page
    },
    encryptInfo() {
      // encrypt passwords
    },
    validateForm() {
      // call validation methods here
    },
    // all validation methods should return a bool
    validateUsername() {
    },
    validateEmail() {
    },
    validatePassword() {
    },
    validatePasswordMatch() {
    },
  }
}
</script>

<style scoped>
button {
  margin: 10px;
  padding: 10px 20px;
  border: 1px solid #000;
  border-radius: 5px;
  background-color: #000;
  color: #fff;
  cursor: pointer;
  border: 1px solid var(--tml-orange);
}
</style>
