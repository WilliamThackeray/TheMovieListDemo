<template>
  <div class="navWrapper">
    <RouterLink to="/"><img alt="Vue logo" class="logo" src="@/assets/TML_white_1.svg" width="125" height="125" />
    </RouterLink>
    <nav>
      <RouterLink to="/home">Home</RouterLink>
      <RouterLink to="/profile">Profile</RouterLink>
      <RouterLink to="/browse">Browse</RouterLink>
      <RouterLink to="/settings">Settings</RouterLink>
    </nav>

    <footer>
      &copy; 2024 William Thackeray
    </footer>
  </div>
</template>

<style scoped>
.navWrapper {
  border: solid 3px var(--tml-orange);
  min-height: 100vh;
  position: fixed;
  padding: 3rem;
  width: 25%;
  font-size: 1.5rem;
  min-width: 200px;
}

.navWrapper,
nav {
  display: flex;
  flex-direction: column;
  align-items: center;
}

nav>* {
  padding: 0.5rem 1rem;
}

nav>*:hover {
  background-color: #f5901542;
}

footer {
  position: fixed;
  width: 25%;
  min-width: inherit;
  left: 0;
  bottom: 0;
  padding: 1rem;
  font-size: 1rem;
  text-align: center;
}
</style>