<script setup>

</script>

<template>
  <form id="registrationForm">
    <label for="username">Username:</label>
    <input type="text" id="username" name="username" required>

    <div id="usernameError" class="error-message"></div>

    <label for="email">Email:</label>
    <input type="email" id="email" name="email" required>

    <div id="emailError" class="error-message"></div>

    <label for="password">Password:</label>
    <input type="password" id="password" name="password" required>

    <div id="passwordError" class="error-message"></div>

    <label for="confirmPassword">Confirm Password:</label>
    <input type="password" id="confirmPassword" name="confirmPassword" required>

    <div id="confirmPasswordError" class="error-message"></div>

    <button type="button" @click="validateForm">Create Account</button>
  </form>
  <div class="error-message" v-if="errors">
    <ul>
      <li v-for="error in errors" :key="error">{{ error }}</li>
    </ul>
  </div>
</template>

<script>
export default {
  data() {
    return {
      errors: [],
    }
  },
  methods: {
    validateForm() {
      let validUName = this.validateUsername();
      let validEmail = this.validateEmail();
      let validPword = this.validatePassword();
      let validPwordConf = this.validateConfirmPassword();

      if (validUName && validEmail && validPword && validPword) {
        // good to send info to server
        fetch('http://localhost:3000/api/user', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            user: {
              username: document.getElementById('username').value,
              email: document.getElementById('email').value,
              password: document.getElementById('password').value
            }
          })
        }).then((res) => {
          if (res.status == 500) {
            console.log("Error: The username is taken, or the email is already conncted to an account.");
            this.errors.push("The username is taken, or the email is already conncted to an account.");
          }
          if (res.status == 200) {
            // redirect and show login
          }
        })
      }
    },

    validateUsername() {
      const usernameInput = document.getElementById('username');
      const usernameError = document.getElementById('usernameError');

      // Your validation logic for the username
      // Example: Check if the username is at least 3 characters long
      if (usernameInput.value.length < 3) {
        usernameError.textContent = 'Username must be at least 3 characters long';
        usernameInput.style.border = '1px solid red';
        return false
      }
      // ALSO NEED TO CHECK IF THE USERNAME IS IN THE DB
      else {
        usernameError.textContent = '';
        usernameInput.style.border = '';
        return true
      }
    },

    validateEmail() {
      // Similar validation logic for email
      // You can use regular expressions or other methods
      const emailInput = document.getElementById('email');
      const emailError = document.getElementById('emailError');


      // Regular expression for a simple email validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

      if (!emailRegex.test(emailInput.value)) {
        emailError.textContent = 'Enter a valid email address';
        emailInput.style.border = '1px solid red';
        return false
      }
      // ALSO NEED TO CHECK IF THE EMAIL IS already tied to an account
      else {
        emailError.textContent = '';
        emailInput.style.border = '';
        return true
      }
    },

    validatePassword() {
      // Validation logic for password
      // Ensure it is longer than 8 characters, has upper and lowercase letters, a number, and a special character
      const passwordInput = document.getElementById('password');
      const passwordError = document.getElementById('passwordError');

      // Regular expression for password validation
      const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

      if (!passwordRegex.test(passwordInput.value)) {
        passwordError.textContent = 'Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one digit, and one special character';
        passwordInput.style.border = '1px solid red';
        return false
      } else {
        passwordError.textContent = '';
        passwordInput.style.border = '';
        return true
      }
    },

    validateConfirmPassword() {
      // Validation logic for confirming the password
      // Check if it matches the original password
      const passwordInput = document.getElementById('password');
      const confirmPasswordInput = document.getElementById('confirmPassword');
      const confirmPasswordError = document.getElementById('confirmPasswordError');

      if (passwordInput.value !== confirmPasswordInput.value) {
        confirmPasswordError.textContent = 'Passwords do not match';
        confirmPasswordInput.style.border = '1px solid red';
        return false
      } else {
        confirmPasswordError.textContent = '';
        confirmPasswordInput.style.border = '';
        return true
      }
    }
  }
}
</script>

<style scoped>
form {
  max-width: 400px;
  margin: 50px auto 0 auto;
}

label {
  display: block;
  margin-bottom: 8px;
  color: var(--tml-orange);
  font-size: large;
  font-weight: 300;
}

input {
  width: 100%;
  padding: 8px;
  margin-bottom: 16px;
  box-sizing: border-box;
  background-color: rgb(179, 179, 179);
  border: solid 1px none;
  border-radius: 5px;
}

button {
  margin: 10px;
  padding: 10px 20px;
  border: 1px solid #000;
  border-radius: 5px;
  background-color: #000;
  color: #fff;
  cursor: pointer;
  border: 1px solid var(--tml-orange);
}

.error-message {
  color: red;
  font-size: 14px;
  margin-top: -8px;
  margin-bottom: 16px;
}
</style>