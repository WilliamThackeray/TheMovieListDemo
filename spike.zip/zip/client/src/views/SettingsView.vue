<script setup>
import Nav from '../components/Nav.vue'
</script>

<template>
  <Nav />
  <div class="settings">
    <h1>This is a Settings page</h1>
  </div>
</template>

<style></style>
