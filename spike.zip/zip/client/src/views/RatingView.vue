<script setup>
import Nav from '../components/Nav.vue'
</script>

<template>
  <Nav />
  <div class="rating">
    <h1>This is a rating page</h1>
  </div>
</template>

<style></style>
