<script setup>
import Nav from '../components/Nav.vue'
</script>

<template>
  <Nav />
  <div class="browse">
    <h1>This is a Browse page</h1>
  </div>
</template>

<style>

</style>
