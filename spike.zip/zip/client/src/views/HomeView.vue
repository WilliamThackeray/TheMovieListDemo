<script setup>
import Post from '../components/Post.vue'
import Nav from '../components/Nav.vue'
</script>

<template>
  <main>
    <Nav />
    <div class="main">
      <h1>This is the Home page</h1>
      <Post />
    </div>
  </main>
</template>

<style scoped>
.navWrapper {
  border: solid 3px var(--tml-orange);
  min-height: 100vh;
  position: fixed;
  padding: 3rem;
  width: 25%;
}

.navWrapper,
nav {
  display: flex;
  flex-direction: column;
}

footer {
  position: fixed;
  left: 0;
  bottom: 0;
  padding: 1rem;
}
</style>