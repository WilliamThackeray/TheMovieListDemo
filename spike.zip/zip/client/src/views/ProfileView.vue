<script setup>
import Nav from '../components/Nav.vue'
</script>

<template>
  <Nav />
  <div class="profile">
    <h1>This is a Profile page</h1>
  </div>
</template>

<style></style>
