<script setup>
import TheLanding from '../components/TheLanding.vue'
import TheLogin from '../components/TheLogin.vue'
import Post from '../components/Post.vue'
import CYAForm from '../components/CYAForm.vue'
</script>

<template>
  <main class="landing">
    <header>
      <img alt="Vue logo" class="logo" src="@/assets/TML_white_1.svg" width="250" height="250" />
      <h1>The Movie List</h1>
      <h2>Start yours today</h2>
    </header>
    <!-- <TheLanding /> -->
    <TheLogin v-if="showLogin" />
    <CYAForm v-if="showForm" />

    <button type="button" @click="cya" v-if="!showForm">Create Your Account</button>
    <button type="button" v-if="showForm" @click="this.cya">Cancel</button>
  </main>
</template>

<script>
export default {
  data() {
    return {
      showLogin: false,
      showForm: false
    }
  },
  methods: {
    login() {
      this.showLogin = !this.showLogin
    },
    cya() {
      this.showForm = !this.showForm
    }
  }
}
</script>

<style scoped>
.landing {
  text-align: center;
}

button {
  margin: 10px;
  padding: 10px 20px;
  border: 1px solid #000;
  border-radius: 5px;
  background-color: #000;
  color: #fff;
  cursor: pointer;
  border: 1px solid var(--tml-orange);
}

footer {
  position: fixed;
  left: 0;
  bottom: 0;
  padding: 1rem;
}
</style>
