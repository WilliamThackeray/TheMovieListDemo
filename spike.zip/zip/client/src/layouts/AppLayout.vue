<script setup>
import Nav from '../components/Nav.vue'
</script>

<template>
  <component :is="this.$route.meta.layoutComponent">
    <Nav />
    <slot />
  </component>
</template>

<script>
// import { lifecycleLoggerMixin } from "@/mixins/lifecycleLoggerMixin";

export default {
  name: "AppLayout",
  // mixins: [lifecycleLoggerMixin],
}
</script>

<style scoped></style>