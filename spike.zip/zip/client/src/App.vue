<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
  <main>
    <div>
      <RouterView />
    </div>
  </main>
</template>

<script>
export default {
  data() {
    return {
    }
  },
  methods: {
    openModal() {

    }
  }
}
</script>

<style scoped>
/* .navWrapper {
  border: solid 3px var(--tml-orange);
  min-height: 100vh;
  position: fixed;
  padding: 3rem;
  width: 25%;
}

.navWrapper,
nav {
  display: flex;
  flex-direction: column;
}

.main {
  margin-left: 25%;
  min-height: 100vh;
}

footer {
  position: fixed;
  left: 0;
  bottom: 0;
  padding: 1rem;
} */
</style>
